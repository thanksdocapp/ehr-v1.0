<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;

class UsersController extends Controller
{
    /**
     * Display a listing of users.
     */
    public function index(Request $request)
    {
        $query = User::with(['department', 'doctor']);
        
        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%")
                  ->orWhere('employee_id', 'like', "%{$search}%");
            });
        }
        
        // Role filter
        if ($request->filled('role')) {
            $query->where('role', $request->role);
        }
        
        // Department filter
        if ($request->filled('department')) {
            $query->where('department_id', $request->department);
        }
        
        // Status filter
        if ($request->filled('status')) {
            $active = $request->status === 'active';
            $query->where('is_active', $active);
        }
        
        // Sorting
        $sortBy = $request->get('sort', 'created_at');
        $sortDirection = $request->get('direction', 'desc');
        $query->orderBy($sortBy, $sortDirection);
        
        $users = $query->paginate(15)->withQueryString();
        $departments = Department::all();
        $roles = User::getRoles();
        
        return view('admin.users.index', compact('users', 'departments', 'roles'));
    }

    /**
     * Show the form for creating a new user.
     */
    public function create()
    {
        $departments = Department::all();
        $roles = User::getRoles();
        
        return view('admin.users.create', compact('departments', 'roles'));
    }

    /**
     * Store a newly created user in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'nullable|string|max:20',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:admin,doctor,nurse,receptionist,pharmacist,technician,staff',
            'department_id' => 'nullable|exists:departments,id',
            'bio' => 'nullable|string|max:1000',
            'specialization' => 'nullable|string|max:255',
            'employee_id' => 'nullable|string|max:50|unique:users',
            'hire_date' => 'nullable|date',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_active' => 'boolean',
            'is_admin' => 'boolean',
        ]);
        
        // Handle avatar upload
        if ($request->hasFile('avatar')) {
            $avatar = $request->file('avatar');
            $avatarName = time() . '_' . Str::random(10) . '.' . $avatar->getClientOriginalExtension();
            $avatar->move(public_path('assets/images/avatars'), $avatarName);
            $validated['avatar'] = $avatarName;
        }
        
        // Generate employee ID if not provided
        if (empty($validated['employee_id'])) {
            $maxAttempts = 100;
            $attempt = 0;
            
            do {
                // Find the next available employee ID
                $lastEmployeeId = User::whereNotNull('employee_id')
                    ->where('employee_id', 'LIKE', 'EMP%')
                    ->orderBy('employee_id', 'desc')
                    ->first()?->employee_id;
                    
                if ($lastEmployeeId) {
                    // Extract number from last employee ID (e.g., EMP0003 -> 3)
                    $lastNumber = intval(substr($lastEmployeeId, 3));
                    $nextNumber = $lastNumber + 1 + $attempt; // Add attempt to avoid conflicts
                } else {
                    $nextNumber = 1 + $attempt;
                }
                
                $proposedEmployeeId = 'EMP' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
                
                // Check if this ID already exists
                $exists = User::where('employee_id', $proposedEmployeeId)->exists();
                
                if (!$exists) {
                    $validated['employee_id'] = $proposedEmployeeId;
                    break;
                }
                
                $attempt++;
            } while ($attempt < $maxAttempts);
            
            if ($attempt >= $maxAttempts) {
                throw new \Exception('Unable to generate unique employee ID after ' . $maxAttempts . ' attempts');
            }
        }
        
        $user = User::create($validated);
        
        return redirect()->route('admin.users.index')
            ->with('success', 'User created successfully!');
    }

    /**
     * Display the specified user.
     */
    public function show(User $user)
    {
        $user->load(['department', 'patient', 'doctor']);
        
        return view('admin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified user.
     */
    public function edit(User $user)
    {
        $departments = Department::all();
        $roles = User::getRoles();
        
        return view('admin.users.edit', compact('user', 'departments', 'roles'));
    }

    /**
     * Update the specified user in storage.
     */
    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
            'phone' => 'nullable|string|max:20',
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|in:admin,doctor,nurse,receptionist,pharmacist,technician,staff',
            'department_id' => 'nullable|exists:departments,id',
            'bio' => 'nullable|string|max:1000',
            'specialization' => 'nullable|string|max:255',
            'employee_id' => ['nullable', 'string', 'max:50', Rule::unique('users')->ignore($user->id)],
            'hire_date' => 'nullable|date',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_active' => 'boolean',
            'is_admin' => 'boolean',
        ]);
        
        // Handle avatar upload
        if ($request->hasFile('avatar')) {
            // Delete old avatar if exists
            if ($user->avatar && file_exists(public_path('assets/images/avatars/' . $user->avatar))) {
                unlink(public_path('assets/images/avatars/' . $user->avatar));
            }
            
            $avatar = $request->file('avatar');
            $avatarName = time() . '_' . Str::random(10) . '.' . $avatar->getClientOriginalExtension();
            $avatar->move(public_path('assets/images/avatars'), $avatarName);
            $validated['avatar'] = $avatarName;
        }
        
        // Only update password if provided
        if (empty($validated['password'])) {
            unset($validated['password']);
        }
        
        $user->update($validated);
        
        return redirect()->route('admin.users.index')
            ->with('success', 'User updated successfully!');
    }

    /**
     * Remove the specified user from storage.
     */
    public function destroy(User $user)
    {
        // Prevent deletion of current admin user
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.users.index')
                ->with('error', 'You cannot delete your own account!');
        }
        
        // Delete avatar if exists
        if ($user->avatar && file_exists(public_path('assets/images/avatars/' . $user->avatar))) {
            unlink(public_path('assets/images/avatars/' . $user->avatar));
        }
        
        $user->delete();
        
        return redirect()->route('admin.users.index')
            ->with('success', 'User deleted successfully!');
    }
    
    /**
     * Toggle user status (active/inactive).
     */
    public function toggleStatus(User $user)
    {
        $user->update(['is_active' => !$user->is_active]);
        
        $status = $user->is_active ? 'activated' : 'deactivated';
        
        return response()->json([
            'success' => true,
            'message' => "User {$status} successfully!",
            'is_active' => $user->is_active
        ]);
    }
    
    /**
     * Reset user password.
     */
    public function resetPassword(User $user)
    {
        $newPassword = Str::random(8);
        $user->update(['password' => Hash::make($newPassword)]);
        
        // Here you would typically send an email with the new password
        // For now, we'll just return it in the response
        
        return response()->json([
            'success' => true,
            'message' => 'Password reset successfully!',
            'new_password' => $newPassword
        ]);
    }
    
    /**
     * Get user statistics for dashboard.
     */
    public function getStats()
    {
        $stats = [
            'total_users' => User::count(),
            'active_users' => User::where('is_active', true)->count(),
            'inactive_users' => User::where('is_active', false)->count(),
            'doctors' => User::where('role', 'doctor')->count(),
            'nurses' => User::where('role', 'nurse')->count(),
            'staff' => User::where('role', 'staff')->count(),
            'recent_users' => User::where('created_at', '>=', now()->subDays(30))->count(),
        ];
        
        return response()->json($stats);
    }
}
